Same-cell RNA and gammaH2AX correspondence: GSE250285

Source: Segeren et al. Molecular Oncology 19, 1633–1650 (2025),
doi:10.1002/1878-0261.13819; GEO GSE250285.
The original study index-sorted RPE1 cells with inducible HRAS G12V after
16 h of gemcitabine 4 nM plus prexasertib 10 nM or vehicle. Numerical gammaH2AX
and DAPI measurements and transcript-count columns share exact cell IDs.

Run all statistical summaries from compact scored data:
  python analysis.py --input all_scored_cells.csv.gz --output results

Recompute fixed scores and summaries from original public expression files:
  python download_sources.py
  python analysis.py --source source --output results

Python dependencies: numpy, pandas, scipy. No classifier is trained.
The optional --bootstrap argument defaults to 2000. These are conditional
within-plate cell-resampling intervals, not independent-culture intervals.

The original 34-gene DDR set is fixed; 32 genes are represented in the supplied
matrix. GADD45G and MRE11 are absent. p53-response and repair/checkpoint
subsets are secondary. Scores use mean log1p(10000*transcript counts/
endogenous library total), excluding only features prefixed ERCC- from that total. Human ERCC repair genes are retained; no ERCC- rows occur in this deposit. Source
processed transcript counts are noninteger and are retained without rounding.
Metadata library sizes agree with original matrix column sums to <0.00005.
All 2,998 paired cells are retained in all_scored_cells.csv.gz; 1,868 pass the
published QC rules. These comprise 354 vehicle and 1,514 drug-treated cells.

The primary analysis uses quantitative gammaH2AX fluorescence within each
of six treated sorting plates, adjusting rank correlations for DAPI,
log endogenous depth and log detected genes. An additional fixed cycle
proxy sensitivity is reported. DDR-high labels use fixed pooled vehicle
references; an HRAS-matched vehicle-reference sensitivity is retained.
No natural population prevalence is inferred from deliberately balanced
fluorescence-gate sampling. The plates are not asserted to be independent
cultures. gammaH2AX is a damage-signalling marker, not repair capacity.

The deposited yh2ax_level categorical field is inversely ordered relative
to the numerical yH2AX_fluorescence field in all six treated plates. Source
values are retained unchanged. source_gate_label_audit.csv documents this
discrepancy; categorical gate AUROC/enrichment is not interpreted and no
labels are silently remapped. Original index-sort/FCS files were absent
from the public supplementary file listing. Related GSE256134 metadata
names an Alexa647 stain channel and has correctly ordered categories;
related_pilot_metadata_audit.csv is a provenance check, not an additional
validation result. The numerical source field is analysed as deposited.

Main plot inputs: primary_plate_summary.csv and scored_cells.csv.gz.
Secondary results: within_plate_DDR_label_associations.csv,
within_plate_associations.csv and condition_association_summary.csv.
within_plate_conditional_intervals.csv supplies conditional sampling
intervals only. source_manifest.json gives exact URLs, sizes and SHA256;
gene_sets.json, checks_and_definitions.json and source_facts.json specify
membership, units, matching, QC and interpretation.

Original article: CC BY 4.0 per the PMC full text. GEO files are publicly
accessible; no separate dataset-specific licence is asserted here.
https://pmc.ncbi.nlm.nih.gov/articles/PMC12161472/
https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE250285
