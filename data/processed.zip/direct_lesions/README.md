# Same-cell transcriptome and physical lesion localization

Source: GSE268554, Nature Methods, DOI 10.1038/s41592-025-02632-3.
The compact paired table retains all 64,794 eligible HeLa barcodes across the
complete control and 0, 2, 6, 24 and 48 h series. Full physical-fragment input is
used; no download prefix or partial fragment stream contributes to the results.

`condition_associations.csv` reports three fixed physical endpoints for all six
conditions, with RNA/DNA QC and cell-cycle/phase adjustment. The physical assay
measures relative lesion localization among captured fragments. It does not
measure absolute lesions per cell. The conserved and treatment-induced regions
are fixed from the source supplement, without selecting regions using RNA.

The control-fixed DDR-high label can lag physical redistribution. Score-quartile
summaries are therefore calculated within condition and original barcode tube;
original capture libraries are retained as technical partitions. Monte Carlo
read-matching and equal-cell-depth ranges describe sampling variation and are
not biological confidence intervals. All six conditions and all fixed
p53/repair subsets are retained, including null or discordant associations.

The repository's single entry point reruns all 11 result CSVs from
`paired_cells.csv.gz`. `--raw lesions` rebuilds the paired table from verified
original sources after `--download-direct lesions`; the download is about 4.3 GB.
The source URLs, checksums, source workbook, fixed region definitions and marker
mapping are preserved in the accompanying manifests. Raw regeneration additionally
requires openpyxl for the original workbook. Original providers' source terms
and attribution apply; no third-party author software is imported or redistributed.
