Biology-informed forecasts with fixed held-out cell lines

The main extension is state_curated_TP53_Gem_pharmacology__cross_entropy.
It adds independently measured TP53 context and three literature-specified,
gemcitabine-specific activation/metabolism summaries to the original four DMSO
transcriptional-state features. It retains all 243 observations, 84 cell lines,
six drug/time regimens, four drugs, five original outer line folds, the same
34-gene normalized transcript endpoint and source-matched DMSO controls.
No treated RNA, viability outcome, numeric line identifier, outcome-selected gene
or new seed is used as an input feature. Every trainable score reference, feature
scaler, penalty and family choice is fitted within its training partition.

Pooled held-out R2 is 0.623163 (4000 line-bootstrap 95% interval 0.506239–0.706707),
versus 0.505826 for the original four-state model. The paired R2 gain is 0.117337
(0.043665–0.190968). The matching TP53/pharmacology-only control reaches 0.572688;
the incremental four-state gain, 0.050475 (−0.011599–0.122406), is uncertain. The
result supports a biology-informed transcriptional forecast, without establishing
that the four original summaries add a robust independent effect beyond known
genetic and pharmacological context. It does not measure physical DNA lesions or
repair kinetics. Within-drug results, including negative Bortezomib R2, remain in
the performance and interval tables.

These are exploratory developments in a resource whose original outer results
were already examined. Frozen plans document each limited extension before its
new fit. The final four families are: TP53-by-regimen context alone; original
states plus context; states/context plus fixed Gem pharmacology; and context plus
pharmacology without the original states. The three pharmacology summaries are
mean(DCK,SLC29A1), CDA and mean(RRM1,RRM2), formed from individual gene log1p10k
values. No further metabolic genes or alternative ratios were screened.

Three inner cell-line folds choose alpha from 0.3, 3 and 30 using fractional
cross-entropy. The same grids are evaluated using MSE as a criterion sensitivity;
this does not choose the criterion with the larger outer R2. An augmented selector
compares the four final families with every earlier fixed candidate family using
inner losses alone. Its primary cross-entropy R2 is 0.602347: states/context wins
one outer fold and states/context/pharmacology four. The MSE selector reaches
0.623959 and selects states/context/pharmacology in all five folds. The final
family is not claimed to have been independently confirmed after development.
Bootstrap intervals resample held-out cell lines with replacement and condition
on the fixed predictions; they do not quantify the model-development process.

TP53 provenance

CCLE2019 mutations from the official cBioPortal API (study ccle_broad_2019;
profile ccle_broad_2019_mutations; TP53 Entrez 7157) match all 84 original publisher
CCLE_IDs exactly. All are members of ccle_broad_2019_sequenced. The fixed coding/
canonical-splice rule identifies 57 qualifying calls and 27 profiled samples
without a qualifying call. No qualifying call does not establish wild-type
function. CCLE2019_classification_plan.json gives the exact accepted classes;
CCLE2019_TP53_variants.csv.gz preserves the reported variant records for the 84
samples, including classes not accepted by that rule. CCLE2019_profiled_samples.csv
preserves the original IDs and mutation-profile coverage. CCLE2019_source_manifest.json
records the original queried payload hashes. Data attribution: Ghandi et al.,
Nature 2019, DOI 10.1038/s41586-019-1186-3, via https://www.cbioportal.org/api.

A literature-based functional-annotation correction includes NCIH2347's synonymous
exon-boundary TP53 c.375G>A (p.Thr125Thr), documented to disrupt splicing but absent
from the nonsynonymous cBioPortal extract. The frozen functional-evidence rule
applies to every affected cohort line. Other literature-reported affected lines,
CAPAN2 and NCIH82, are absent from this cohort. The curated count is 58 qualifying
and 26 without a qualifying annotation, with no unknowns. The correction is
attributed in TP53_literature_splice_curation.csv and curated_genotype_plan.json:
Leroy et al., PMID 24700732, DOI 10.1002/humu.22556; Iwakawa et al., PMID 20557307,
DOI 10.1111/j.1349-7006.2010.01622.x; Cellosaurus RRID CVCL_1550.
The original 57-call definition remains an explicit sensitivity: pooled R2
0.613717 (0.499259–0.698260). Frozen plans retain the original raw-call definition
alongside the later curation rule. The earlier source-annotation/Idasanutlin-only
analysis is separate; it does not replace the complete 84-line genetic-context
comparison. Source annotation agrees for 23/24 with raw calls and 24/24 after
literature curation. An absent qualifying annotation is never labeled functional
wild-type.

Reproduction

Use the original software package's forecast and source_context inputs and its
methods directory containing nested_forecasting.py, source_matched_forecasting.py
and context/. Python dependencies are numpy, pandas, scipy, scikit-learn and h5py.
The existing package requirements specify the tested analysis environment.

  python code/reproduce_extension.py --forecast-inputs INPUTS/forecast \
    --context-inputs INPUTS/source_context --methods METHODS \
    --records THIS_DIRECTORY --output RESULTS

This recomputes metrics and 4000 paired line-bootstrap intervals and reconstructs
all 40 held-out parameter records per annotation definition. Add --refit to rerun
the unchanged four-family nested grids and inner-only augmented selector using
the compact control scores, without downloading the original expression matrix.
Fresh nested refits of both annotation definitions reproduce every held-out
prediction exactly. The final 243 observations and all 84 lines remain unchanged.

  python code/rebuild_genotype_annotations.py --records THIS_DIRECTORY \
    --output GENOTYPE_RESULTS

This rebuilds the 57 raw and 58 curated annotations from the compact source
variant extract, mutation-profile coverage and fixed literature correction.

To regenerate the five pharmacology genes directly, add --raw ORIGINAL.h5ad to
--refit. The original public file is McFarlandTsherniak2020.h5ad, available at
https://zenodo.org/api/records/7041849/files/McFarlandTsherniak2020.h5ad/content
(SHA256 94a7240047b9ce6822dc2aa1e7a66c1fd8b00be842e5a95fc72cbeb6f2834d2c).
pharmacology_control_scores.csv.gz contains only the three source-derived module
values for 8718 eligible DMSO cells and their compact/original observation rows.
No treated expression is present. Original module inputs use their existing
gene_identity_map.json and original source-row mapping. feature_schema.json
specifies coefficient and biological feature order; fitted parameter records
contain fold-specific feature centers/scales and coefficients, and separate fold
references contain training-only score centers/scales. These are held-out-fold
parameters, not an independently validated full-data deployment model.

Files and prior candidates

curated_all_outer_predictions.csv.gz, curated_all_performance.csv and
curated_biology_line_bootstrap.csv contain every final family, both criteria,
selectors and original comparators. The uniform_* equivalents retain the original
57-call definition. primary_model_diagnostics.csv and primary_model_count_strata.csv
report calibration and descriptive cell-count sensitivity without changing the
primary endpoint or weighting. primary_selection_counts.csv gives inner-selector
choices. No low-count or influential observation is removed.

prior_family_predictions.csv.gz retains all earlier fixed candidates: programme,
distribution, shallow nonlinear and targeted source-TP53 families; transcriptome-PC
extensions; and their cross-entropy/MSE selectors. all_performance.csv and
all_line_bootstrap.csv give those results. These earlier families did not provide
a material pooled improvement. Their code and frozen plans remain available so
that unsuccessful development is visible. Optional extract_transcriptome.py
regenerates the 12MB baseline pseudobulk matrix from the public source; only
DMSO controls contribute. Fold-specific variance selection, scaling and PCA use
training populations only. transcriptome_fitted_parameters.json.gz preserves
the selected genes and transformations without redistributing the whole matrix.

The source-annotation Idasanutlin/PRISM results are descriptive secondary checks.
Their association is largely explained by the known TP53 annotation; it is not an
independent repair or resistance predictor. Binomial sampling-noise estimates in
sampling_noise_reference.csv assume independent cells and are descriptive
references, not an absolute biological noise ceiling or an adjusted R2 endpoint.
Original source data retain their providers' terms and attribution.
